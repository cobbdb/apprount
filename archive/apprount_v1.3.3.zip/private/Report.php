<?php

/**
 * Report.php
 * 
 * @author Dan Cobb
 * @since 1.3.3
 * @date October 4, 2012
 */


require_once $_SERVER["DOCUMENT_ROOT"] . "/util/Engine.php";

/**
 * Report is a collection of Pages.
 */
class Report {
    private $pages;
    private $searchDepth;
    private $totalViews = 0;
    private $totalPages = 0;
    
    public function __construct($searchDepth, $pages) {
        $this->searchDepth = $searchDepth;
        $this->pages = $pages;
        
        foreach ($pages as $page) {
            $this->totalViews += $page->getAllViews();
            $this->totalPages += $page->getSubpageCnt() + 1;
        }
    }
    
    public function toHTML() {
        return $this->render("./private/views/pages/report.html.view");
    }
    
    public function toWiki() {
        return $this->render("./private/views/pages/report.wiki.view");
    }
    
    public function toCSV() {
        return $this->render("./private/views/pages/report.csv.view");
    }
    
    private function render($view) {
        return Template::render($view, Array(
            "searchDepth" => $this->searchDepth,
            "totalViews" => $this->totalViews,
            "totalPages" => $this->totalPages,
            "pages" => $this->pages
        ));
    }
}
