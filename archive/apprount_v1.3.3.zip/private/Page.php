<?php
    
/**
 * Page.php
 * 
 * @author Dan Cobb
 * @since 1.3.3
 * @date October 4, 2012
 */


require_once $_SERVER["DOCUMENT_ROOT"] . "/util/Engine.php";


abstract class Page {
    /**
     * Check if a title begins with the category prefix.
     * @returns {Boolean}
     */
    public static function isCategory($title) {
        return preg_match("/^(Category:)/i", $title);
    }
    
    /**
     * @returns {Boolean} True if page is not broken.
     */
    public static function isHealthy($page) {
        // healthy pages have a view counter key
        if (isset($page["counter"])) {
            return true;
        }
        return false;
    }
    
    
    protected $title, $views, $depth, $uri, $link;
    protected $subpages = Array();
    protected $subcats = Array();
    
    public abstract function toHTML();
    public abstract function toWiki($searchDepth);
    public abstract function toCSV($parentTitle);
    
    public function __construct($title, $views, $depth) {
        $this->title = $title;
        $this->views = $views;
        $this->depth = $depth;
        $this->uri = "appropedia.org/" . $title;
        
        // Some titles contain slashes, so encode only each
        //   subpath of the title.
        $pathSections = explode("/", $title);
        $encodedSections = Array();
        foreach ($pathSections as $subpath) {
            $encodedSections[] = urlencode($subpath);
        }
        $this->link = "http://www.appropedia.org/" . implode("/", $encodedSections);
    }
    
    
    public function getTitle() {
        return $this->title;
    }
    
    public function getSubpageCnt() {
        $count = sizeof($this->subpages);
        foreach ($this->subcats as $page) {
            $count += $page->getSubpageCnt();
        }
        return $count;
    }
    
    public function getSubcatCnt() {
        $count = sizeof($this->subcats);
        foreach ($this->subcats as $page) {
            $count += $page->getSubcatCnt();
        }
        return $count;
    }
    
    public function getAllViews() {
        $count = $this->views;
        foreach ($this->subpages as $page) {
            $count += $page->getAllViews();
        }
        return $count;
    }
    
    public function addPage($page) {
        if (Page::isCategory($page->getTitle())) {
            $this->subcats[] = $page;
        } else {
            $this->subpages[] = $page;
        }
    }
}



class ContentPage extends Page {
    public function toHTML() {
        return Template::render("./private/views/pages/contentpage.html.view", Array(
            "indent" => $this->depth * 22,
            "title" => $this->title,
            "views" => $this->views,
            "link" => $this->link,
            "uri" => $this->uri
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/contentpage.wiki.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "depth" => $this->depth,
            "searchDepth" => $searchDepth
        ));
    }
    
    public function toCSV($parentTitle) {
        return Template::render("./private/views/pages/contentpage.csv.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "uri" => $this->uri,
            "parentTitle" => $parentTitle
        ));
    }
}



/**
 * Broken pages are those with incorrect query titles.
 * These hold no view or uri information.
 */
class BrokenPage extends Page {
    public function __construct($title, $depth) {
        parent::__construct($title, 0, $depth);
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/brokenpage.html.view", Array(
            "indent" => $this->depth * 22,
            "alt" => "broken page",
            "title" => $this->title,
            "msg" => "Page Not Found"
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/brokenpage.wiki.view", Array(
            "depth" => $this->depth,
            "searchDepth" => $searchDepth,
            "msg" => "Page Not Found: " . $this->title
        ));
    }
    
    public function toCSV($parentTitle) {
        return Template::render("./private/views/pages/brokenpage.csv.view", Array(
            "msg" => "Page Not Found: " . $this->title,
            "parentTitle" => $parentTitle
        ));
    }
}



/**
 * CategoryPage is a child of Page that contains a
 * collection of subpages.
 */
class CategoryPage extends Page {
    /** Next available category id. */
    private static $maxCatID = 0;
    /** Unique page id. */
    private $catID;
    
    public function __construct($title, $views, $depth) {
        parent::__construct($title, $views, $depth);
        $this->catID = self::$maxCatID;
        self::$maxCatID += 1;
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/categorypage.html.view", Array(
            "indent" => $this->depth * 22,
            "catID" => $this->catID,
            "title" => $this->title,
            "link" => $this->link,
            "uri" => $this->uri,
            "views" => $this->views,
            "totalViews" => $this->getAllViews(),
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "subpages" => array_merge($this->subpages, $this->subcats)
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/categorypage.wiki.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "depth" => $this->depth,
            "searchDepth" => $searchDepth,
            "totalViews" => $this->getAllViews(),
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "subpages" => array_merge($this->subpages, $this->subcats)
        ));
    }
    
    public function toCSV($parentTitle) {
        return Template::render("./private/views/pages/categorypage.csv.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "totalViews" => $this->getAllViews(),
            "uri" => $this->uri,
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "subpages" => array_merge($this->subpages, $this->subcats),
            "parentTitle" => $parentTitle
        ));
    }
}



/**
 * Leaf category pages are those at the edge of the
 * search depth and, therefore, have no subpages.
 */
class LeafCategory extends Page {
    public function toHTML() {
        return Template::render("./private/views/pages/leafcategory.html.view", Array(
            "indent" => $this->depth * 22,
            "title" => $this->title,
            "views" => $this->views,
            "totalViews" => $this->getAllViews(),
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "link" => $this->link,
            "uri" => $this->uri
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/categorypage.wiki.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "depth" => $this->depth,
            "searchDepth" => $searchDepth,
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "totalViews" => $this->getAllViews()
        ));
    }
    
    public function toCSV($parentTitle) {
        return Template::render("./private/views/pages/categorypage.csv.view", Array(
            "title" => $this->title,
            "views" => $this->views,
            "totalViews" => $this->getAllViews(),
            "uri" => $this->uri,
            "cntSubpagesDirect" => sizeof($this->subpages),
            "cntSubpagesTotal" => $this->getSubpageCnt(),
            "cntSubcategoriesDirect" => sizeof($this->subcats),
            "cntSubcategoriesTotal" => $this->getSubcatCnt(),
            "parentTitle" => $parentTitle
        ));
    }
}
