
// max rows in the query bar
var max_rows = 18;


// add a new page title to the list
function add_title(event, text_area) {
    // add new title to list on every enter
    if (event.keyCode == 13) {
        var i, lines;
        // split text into array of substrings
        lines = text_area.value.split("\n");
        
        // check if last line is not empty -> no spamming
        if (lines.pop() != "") {
            // since will be returning false, insert line break
            text_area.value += "\n";
            
            // add an extra line
            if (text_area.rows < max_rows) {
                text_area.rows += 1;
            }
            
            // bottom-out scroll bar
            text_area.scrollTop = text_area.scrollHeight;
        }
        return false; // block form submit
    }
    return true;
}


// adjust textarea height to match contents
function resize_height(text_area) {
    // calibrate row value -> pasting does not increase row cnt
    var lines = text_area.value.split("\n");
    text_area.rows = Math.min(max_rows, lines.length);
    
    // calibrate textarea height
    text_area.style.height = "auto";
}


// prep form information for submit
//   or deny submit if no values for query or depth
function validateQuery(form) {
    // deny submit if no titles
    if (form.elements[0].value === "") {
        return false;
    }
    // deny submit if invalid depth
    var depth = form.elements[1].value;
    if (depth.search(/[0-6]/) < 0) {
        return false;
    }
    
    // hide form and show busy message
    show_busy(depth);
    
    // convert title list into query
    var query = form.elements[0].value;
    while (query.search(/\r?\n/) >= 0) {
        // replace all line breaks
        query = query.replace(/\r?\n/, "|"); // pipe-delimited
    }
    while (query.search(/\|\|+/) >= 0) {
        // replace all consecutive pipes
        query = query.replace(/\|\|+/, "|"); // delete one of the two
    }
    query = query.replace(/\|$/, ""); // remove trailing pipes
    form.elements[0].value = query;
    
    // proceed with form submit
    return true;
}


// show busy symbol to user
function show_busy(depth) {
    // hide form and show busy div
    document.getElementById("form_div").style.display = "none";
    document.getElementById("busy_div").style.display = "inline";
    
    // begin recursing estimate
    updateEstimate(depth, 0);
}


// update time estimate based on elapsed time in seconds
function updateEstimate(depth, time_elapsed) {
    // to int
    depth = parseInt(depth);
    
    // estimate 2s per page w/ ~4 subpages per page
    var unit = " seconds";
    var new_estimate = 2 * Math.pow(4, depth) - time_elapsed;
    if (new_estimate > 60) {
        // go to seconds > 1min
        unit = " minutes";
        new_estimate /= 60; // to min
        new_estimate = Math.round(new_estimate);
    }
    new_estimate = Math.max(new_estimate, 0); // clamp at 0
    
    // set new estimate into page
    document.getElementById("time_est").innerHTML = new_estimate + unit;
    
    // recurse in 1 second
    time_elapsed += 2;
    setTimeout(function () {
        updateEstimate(depth, time_elapsed);
    }, 1000 * 2);
}


// IE fix for animated gif during form submit
// Adapted from: http://www.stillnetstudios.com/animated-in-progress-indicator-for-long-running-pages/
var submitted = false;
function doSubmit() {
    if (!submitted) {
        submitted = true;
        ProgressImg = document.getElementById("inprogress_img");
        setTimeout("ProgressImg.src = ProgressImg.src", 100);
        return true;
    }
    return false;
}


// Toggle expansion or compression of a div
// Adapted from: http://www.harrymaugans.com/2007/03/05/how-to-create-a-collapsible-div-with-javascript-and-css/
function toggleDiv(divid) {
    if (document.getElementById(divid).style.display == "none") {
        document.getElementById(divid).style.display = "block";
        var img_tag = document.getElementById("icon_" + divid).innerHTML;
        img_tag = img_tag.replace(/plus/, "minus");
        document.getElementById("icon_" + divid).innerHTML = img_tag;
    } else {
        document.getElementById(divid).style.display = "none";
        var img_tag = document.getElementById("icon_" + divid).innerHTML;
        img_tag = img_tag.replace(/minus/, "plus");
        document.getElementById("icon_" + divid).innerHTML = img_tag;
    }
}


