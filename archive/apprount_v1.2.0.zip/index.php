<?php

/**
 * api.php
 * API for Apprount
 * 
 * Counts pageviews for pages linked under any
 * appropedia category page.
 * Echos back results page filled with page view reports.
 *
 * <fname>.php?title=<page title>
 * 
 * By: Dan Cobb (cobbdb@gmail.com)
 * Last Modified: July 24, 2012
 */

include_once("./private/ApprountApi.php");

/**
 * Site states are:
 * - prompt = welcome page with search prompt
 * - search = query api for page view information
 * - report = display results to user
 */
session_start();

// new session created -> set starting state
if(!isset($_SESSION["state"])) {
    $_SESSION["state"] = "prompt";
}

// check for incoming queries
// . ignore if busy doing another query
if($_SESSION["state"] != "search" and isset($_REQUEST["titles"])) {
    $_SESSION["state"] = "search";
}


// handle state
switch($_SESSION["state"]) {
    case "prompt":
        // show main apprount page
        echo file_get_contents("./private/search.html");
        break;
    
    case "search":
        // die if session is already searching
        if(isset($_SESSION["titles"])) {
            session_destroy();
            throw new Exception("Error: Search already in progress.");
        }
        
        // store search query
        $_SESSION["titles"] = $_REQUEST["titles"];
        $_SESSION["depth"] = $_REQUEST["depth"];
        unset($_REQUEST["titles"]);
        unset($_REQUEST["depth"]);
        
        // calculate page view information
        $report_html = ApprountAPI::createReportHTML($_SESSION["depth"], $_SESSION["titles"]);
        
        // show results
        $_SESSION["state"] = "report";
        
        // fallthrough VVVVV
    case "report": // show query results
        // check for no report
        if(!isset($report_html)) {
            throw new Exception("Error: API did not respond.");
        }
        
        // grab page template
        $page_html = file_get_contents("./private/results.html");
        
        // place report in template and output
        echo preg_replace("%!contents!%", $report_html, $page_html);
        
        // end session
        session_destroy();
        break;
}


