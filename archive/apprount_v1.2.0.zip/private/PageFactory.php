
<?php

/**
 * Page_Factory.php
 * 
 * Factory for all Pages. Single point of entry with
 *     internal branching.
 * 
 * By: Dan Cobb
 * Last Modified: July 24, 2012
 */

include_once("Page.php");

class PageFactory {
    // Seam for Page class
    // RETURNS: Instance of an appropriate Page child based on xml
    public static function newPage($pageXML, $pageDepth, $searchDepth) {
        // check for category
        if(Page::title_is_category($pageXML["title"])) {
            return PageFactory::newCategory($pageXML, $pageDepth, $searchDepth);
        }
        // otherwise, a leaf page
        return PageFactory::newLeaf($pageXML, $pageDepth);
    }
    
    // RETURNS: true if xml is of an actual page.
    private static function xmlIsHealthy($pageXML) {
        // healthy pages have a view counter key
        if(isset($pageXML["counter"])) {
            return true;
        }
        // .. broken pages do not
        return false;
    }
    
    
    
    // Creates either a Content_Page or a Broken_Page
    private static function newLeaf($pageXML, $pageDepth) {
        if(PageFactory::xmlIsHealthy($pageXML)) {
            return PageFactory::newContentPage($pageXML["title"], $pageXML["counter"], $pageDepth);
        }
        return PageFactory::newBrokenPage($pageXML["title"], $pageDepth);
    }
    
    private static function newContentPage($title, $views, $depth) {
        return new Content_Page($title, $views, $depth);
    }
    
    private static function newBrokenPage($title, $depth) {
        return new Broken_Page($title, $depth);
    }
    
    
    
    // Creates one of: categoryPage, Leaf_Category, Broken_Category
    private static function newCategory($pageXML, $pageDepth, $searchDepth) {
        if(PageFactory::xmlIsHealthy($pageXML)) {
            // healthy categories have two types: node and leaf
            if($pageDepth < $searchDepth) {
                return self::newCategoryPage($pageXML["title"], $pageXML["counter"], $pageDepth, $searchDepth);
            }
            return self::newLeafCategory($pageXML["title"], $pageXML["counter"], $pageDepth);
        }
        return self::newBrokenCategory($pageXML["title"], $pageDepth);
    }
    
    private static function newCategoryPage($title, $views, $pageDepth, $searchDepth) {
        // collect information on category
        $categoryReport = ApprountAPI::newCategoryReport($title);
        
        // create empty category page
        $categoryPage = new Category_Page($title, $views, $pageDepth);
        
        // query api
        $xml_obj_api_reports = ApprountAPI::queryAppropedia($categoryReport->getSubpageTitles());
        
        // add pages to category page
        foreach($xml_obj_api_reports as $apiReport) {
            // for each page in each report
            foreach($apiReport->query->pages->page as $xml_page_report) {
                // recurse to create the new page
                $newPage = PageFactory::newPage($xml_page_report, $pageDepth + 1, $searchDepth);
                
                // add new page to category
                $categoryPage->add_page($newPage);
            }
        }
        
        // return category page
        return $categoryPage;
    }
    
    private static function newLeafCategory($title, $views, $depth) {
        // collect information on category
        $categoryReport = ApprountAPI::newCategoryReport($title);
        
        $subpageCount = $categoryReport->getSubpageCount();
        $subcategoryCount = $categoryReport->getSubcategoryCount();
        
        // create the empty category page
        $categoryPage = new Leaf_Category($title, $views, $depth, $subpageCount, $subcategoryCount);
        
        // return new page
        return $categoryPage;
    }
    
    private static function newBrokenCategory($title, $depth) {
        return new Broken_Category($title, $depth);
    }
}



