<?php

$pageTitle = rawurlencode("Category:Electricity");

$query = "action=query&format=php&list=categorymembers&cmprop=title|ids|type&cmlimit=500&cmtitle=$pageTitle";
$url = "http://appropedia.org/api.php?$query";

echo "Sending query at: $url<br/><br/>";

$response = file_get_contents($url);
$data = unserialize($response);

echo("<ul>");
foreach($data["query"]["categorymembers"] as $page) {
    echo("<li>{$page["title"]} ({$page["type"]})</li>");
}
echo("</ul>");