<?php

/**
 * Apprount_Api.php
 * API for Apprount
 * 
 * Counts pageviews for pages linked under any
 * appropedia category page.
 * Echos back results page filled with page view reports.
 *
 * <fname>.php?depth=<search depth>&titles=<page title>
 * 
 * By: Dan Cobb (cobbdb@gmail.com)
 * Last Modified: July 24, 2012
 */

include_once("Page.php");
include_once("PageFactory.php");


/////////////////////////////////////////
// Apprount API Definition


// Contains information on a category
class CategoryReport {
    private $pageTitles;
    private $categoryCount = 0;
    
    // PARAM: titles is an array of page titles
    public function __construct($titles) {
        $this->pageTitles = $titles;
        foreach($this->pageTitles as $title) {
            if(Page::title_is_category($title)) {
                $this->categoryCount++;
            }
        }
    }
    
    public function getSubpageTitles() {
        return $this->pageTitles;
    }
    
    public function getSubpageCount() {
        return sizeof($this->pageTitles);
    }
    
    public function getSubcategoryCount() {
        return $this->categoryCount;
    }
}


// Collection of tools to handle Appropedia page operations
final class ApprountAPI {
    // Create html for an Apprount search query
    public static function createReportHTML($searchDepth, $titlesString) {
        // parse string of titles
        $approTitles = explode("|", $titlesString);
        
        // query appropedia api for page information
        $xmlObjApiReports = self::queryAppropedia($approTitles);
        
        // create a new report
        $report = new Report($searchDepth);
        
        // add pages to report
        foreach($xmlObjApiReports as $apiReport) {
            // for each page in each report
            foreach($apiReport->query->pages->page as $xmlPageReport) {
                // create the new page
                $newPage = PageFactory::newPage($xmlPageReport, 0, $searchDepth);
                
                // add new page to category
                $report->add_page($newPage);
            }
        }
        
        // conver the report to html
        return $report->to_html();
    }
    
    
    // Factory for category report
    public static function newCategoryReport($categoryTitle) {
        // create list of titles
        $titleList = self::getAllTitles($categoryTitle);
        // create a new category report
        return new CategoryReport($titleList);
    }
    
    
    // Create an array of xml reports from Appropedia API
    public static function queryAppropedia($pageTitles) {
        // create the collection of reports
        return self::getSubpageInfo($pageTitles);
    }
    
    
    
    
    /////////////////////////////////////////
    // Private Methods
    
    
    // Collect entire list of subpage titles from starting page.
    // PARAMS: approHost appropedia domain url
    //         rootPage root page to search through
    // RETURNS: comprehensive array of page titles
    private static function getAllTitles($rootPage) {
        $titles = Array();
        
        // create query
        $rootPage = rawurlencode($rootPage);
        $query = "action=query&format=php&list=categorymembers&cmprop=title&cmlimit=500&cmtitle=$rootPage";
        $continueCode = "";
        
        do {
            $url = "http://appropedia.org/api.php?" . $query . $continueCode;
            
            // query the api
            $response = file_get_contents($url);
            $data = unserialize($response);
            
            // add page titles to list
            foreach($data["query"]["categorymembers"] as $page) {
                $titles[] = $page["title"];
            }
            
            // check if more than 500 members
            $continue = isset($data["query-continue"]);
            if($continue) {
                $continueCode = "&cmcontinue=" . $data["query-continue"]["categorymembers"]["cmcontinue"];
            }
        } while($continue);
        
        return $titles;
    }
    
    
    // Queries the framework for all titles
    // PARAMS: titles of all subpages.
    // RETURNS: array of subpages' info as (title, count)
    private static function getSubpageInfo($titles) {
        // map of (title, count) for subpages
        $xml_reports = Array();
        
        // number of pages LEFT to get info on
        $total_size = sizeof($titles);
        
        // api will only report back 50 pages at a time, so
        //    iterate through titles 50 at a time
        $num_iterations = ceil($total_size / 50);
        
        // build the query
        for($i=0; $i<$num_iterations; $i++) {
            // reset query
            $query = "";
            
            // calculate how many titles to add
            $query_size = min($total_size, 50);
            
            // add to the query
            for($j=0; $j<$query_size; $j++) {
                $title_index = $j + $i*50;
                $query .= $titles[$title_index] . "|";
            }
            $query = substr($query, 0, -1); // drop last pipe
            
            // mark that a batch of titles have been added
            $total_size -= $query_size;
            
            // create the url
            $query_url = "http://www.appropedia.org/api.php?format=xml&action=query&prop=info&titles=";
            $query_url .= rawurlencode($query); // encode the query
            
            // query the api
            $xml_string = file_get_contents($query_url);
            // create the XML object
            $xml_reports[] = new SimpleXMLElement($xml_string);
        }
        
        return $xml_reports;
    }
}



