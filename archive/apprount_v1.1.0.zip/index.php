<?php
	
	/**
	 * api.php
	 * API for Apprount
	 * 
	 * Counts pageviews for pages linked under any
	 * appropedia category page.
	 * Echos back results page filled with page view reports.
	 *
	 * <fname>.php?title=<page title>
	 * 
	 * By: Dan Cobb (cobbdb@gmail.com)
	 * Last Modified: March 16, 2012
	 */
	
	include_once("./private/Apprount_Api.php");
	
	/**
	 * Site states are:
	 * - prompt = welcome page with search prompt
	 * - search = query api for page view information
	 * - report = display results to user
	 */
	session_start();
	
	// new session created -> set starting state
	if( !isset($_SESSION["state"]) )
		$_SESSION["state"] = "prompt";
	
	// check for incoming queries
	// . ignore if busy doing another query
	if( $_SESSION["state"] != "search" and isset($_REQUEST["titles"]) )
		$_SESSION["state"] = "search";
	
	
	// handle state
	switch( $_SESSION["state"] )
	{
	case "prompt":
		// show main apprount page
		echo file_get_contents("./private/search.html");
		break;
	
	case "search":
		//session_destroy();
		// store search query
		$_SESSION["titles"] = $_REQUEST["titles"];
		$_SESSION["depth"] = $_REQUEST["depth"];
		unset( $_REQUEST["titles"] );
		unset( $_REQUEST["depth"] );
		
		// calculate page view information
		$report_html = Apprount_API::create_report_html($_SESSION["depth"], $_SESSION["titles"]);
		
		// show results
		$_SESSION["state"] = "report";
		
		// fallthrough VVVVV
	case "report": // show query results
		// check for no report
		if( !isset($report_html) )
			throw new Exception("Something bad happened :[");
		
		// grab page template
		$page_html = file_get_contents("./private/results.html");
		
		// place report in template and output
		echo preg_replace("%!contents!%", $report_html, $page_html);
		
		// end session
		session_destroy();
		break;
	}
	
?>
