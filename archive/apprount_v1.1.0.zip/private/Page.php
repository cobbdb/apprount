
<?php
	
	/**
	 * Page.php
	 * 
	 * Abstract Page parents Content_Page and Category_Page.
	 * Content_Page is a leaf, while Category_Page is a node
	 *     that also has many properties of a leaf.
	 * 
	 * The HTML template is described in report_template.txt
	 * 
	 * By: Dan Cobb
	 * Last Modified: 3/25/12
	 */
	
	
	// Defines the contract of a Page
	abstract class Page
	{
		protected $page_title = "UNREGISTERED_PAGE";
		protected $page_views = -1;
		protected $page_url = "UNREGISTERED_PAGE";
		protected $page_link = "UNREGISTERED_PAGE";
		protected $page_depth = -1;
		
		public abstract function to_html();
		public abstract function get_views();
		public abstract function get_worth();
		public abstract function get_page_cnt();
		public abstract function get_category_cnt();
		
		public function get_title()
		{
			return $this->page_title;
		}
		
		// check if a title begins with Category:
		public static function title_is_category( $title )
		{
			// i indicates case-insensitivity
			return (preg_match("/^(Category:)/i", $title) == 1);
		}
	}
	
	
	/**
	 * Content_Page is a leaf of the report heirarchy containing
	 *     pageview information, url, and toHTML/0
	 */
	class Content_Page extends Page
	{
		public function __construct( $title, $views, $depth )
		{
			$this->page_title = $title;
			$this->page_views = $views;
			$this->page_depth = $depth;
			$this->page_url = "appropedia.org/" . $title;
			$this->page_link = "http://www.appropedia.org/" . rawurlencode($title);
		}
		
		// return total number of views on page
		public function get_views()
		{
			return $this->page_views;
		}
		
		// return 1 if healthy page, 0 if broken page
		public function get_worth()
		{
			return 1;
		}
		
		// return 1 if healthy page, 0 if broken page
		public function get_page_cnt()
		{
			return 1;
		}
		
		// return total number of categories in page
		public function get_category_cnt()
		{
			return 0;
		}
		
		public function to_html()
		{
			$indent = $this->page_depth*22;
			return <<<PAGE_HTML
<div class="result_div healthy page" style="margin-left:{$indent}px">
	<div class="result_icon">
		<img src="./img/icon_page.png" alt="healthy page"/>
	</div>
	<div class="result_body">
		<span class="result_query">$this->page_title</span>
		<span class="result_views">$this->page_views views</span>
		<br/>
		<span class="result_url">
			<a href="$this->page_link" target="_blank">$this->page_url</a>
		</span>
	</div>
</div>
PAGE_HTML;
		}
	}
	
	
	
	/**
	 * Broken pages are those with incorrect query titles.
	 *     These hold no view or url information.
	 */
	class Broken_Page extends Content_Page
	{
		public function __construct( $title, $depth )
		{
			$this->page_title = $title;
			$this->page_depth = $depth;
		}
		
		public function get_views()
		{
			return 0;
		}
		
		public function get_worth()
		{
			return 0;
		}
		
		public function get_page_cnt()
		{
			return 0;
		}
		
		public function to_html()
		{
			$indent = $this->page_depth*22;
			return <<<PAGE_HTML
<div class="result_div broken page" style="margin-left:{$indent}px">
	<div class="result_icon">
		<img src="./img/icon_broken.png" alt="broken page"/>
	</div>
	<div class="result_body">
		<span class="result_query">$this->page_title</span>
		<br/>
		<span class="result_url">
			Page Not Found
		</span>
	</div>
</div>
PAGE_HTML;
		}
	}
	
	
	
	/**
	 * Category_Page is a child of Page that contains a
	 *     collection of subpages.
	 */
	class Category_Page extends Content_Page
	{
		// Next available category id
		private static $max_cat_id = 0;
		// Each new category gets a unique page id
		private $cat_id;
		
		private $subpages = array();
		
		private $subpage_cnt = 0;
		private $subcategory_cnt = 0;
		
		public function __construct( $title, $views, $depth )
		{
			parent::__construct($title, $views, $depth);
			$this->cat_id = self::$max_cat_id++;
		}
		
		public function add_page( $new_subpage )
		{
			// check if page is a category
			if( parent::title_is_category($new_subpage->get_title()) )
				$this->subcategory_cnt += $new_subpage->get_worth();
			// add page to collection
			$this->subpages[] = $new_subpage;
			$this->subpage_cnt += $new_subpage->get_worth();
		}
		
		// calculate total number of views for category and
		//     its subPAGES and all subpages for subcategories
		public function get_views()
		{
			$total_views = $this->page_views;
			foreach( $this->subpages as $page )
				$total_views += $page->get_views();
			
			return $total_views;
		}
		
		// calculate total number of subCATEGORIES for category
		public function get_category_cnt()
		{
			$total_categories = 1;
			foreach( $this->subpages as $page )
				$total_categories += $page->get_category_cnt();
			
			return $total_categories;
		}
		
		// calculate total number of pages in category
		public function get_page_cnt()
		{
			$total_pages = 1;
			foreach( $this->subpages as $page )
				$total_pages += $page->get_page_cnt();
			
			return $total_pages;
		}
		
		public function to_html()
		{
			// calculate page information
			$cnt_subpages_direct = $this->subpage_cnt;
			$cnt_subpages_total = $this->get_page_cnt() - 1;
			$cnt_subcategories_direct = $this->subcategory_cnt;
			$cnt_subcategories_total = $this->get_category_cnt() - 1;
			$total_views = $this->get_views();
			
			// add category page's html
			$indent = $this->page_depth*22;
			$category_html = <<<PAGE_HTML
<div class="result_div healthy category" style="margin-left:{$indent}px" onclick="toggleDiv('div_$this->cat_id');">
	<div class="result_icon" id="icon_div_$this->cat_id">
		<img src="./img/icon_plus.png" alt="healthy category"/>
	</div>
	<div class="result_body">
		<span class="result_query">$this->page_title</span>
		<span class="result_views">$this->page_views views</span>
		<br/>
		<div class="result_description">
			<span class="result_text_total">$total_views</span> total views of category page and contents.<br/>
			<span class="result_text_details">
				SubPages: $cnt_subpages_direct direct / $cnt_subpages_total total - SubCategories: $cnt_subcategories_direct direct / $cnt_subcategories_total total
			</span>
		</div>
		<span class="result_url">
			<a href="$this->page_link" target="_blank">$this->page_url</a>
		</span>
	</div>
</div>
PAGE_HTML;
			
			// add category subpages' html
			$category_html .= <<<PAGE_HTML
<div id="div_$this->cat_id" class="result_contents" style="display:none;">
PAGE_HTML;
			foreach( $this->subpages as $page )
				$category_html .= $page->to_html();
			
			$category_html .= "</div>";
			
			return $category_html;
		}
		
	}
	
	
	
	/**
	 * Leaf category pages are those at the edge of the
	 *     search depth and, therefore, have no subpages.
	 */
	class Leaf_Category extends Content_Page
	{
		private $subpage_cnt = 0;
		private $subcategory_cnt = 0;
		
		public function __construct( $title, $views, $depth, $num_subpages, $num_subcats )
		{
			parent::__construct($title, $views, $depth);
			$this->subpage_cnt = $num_subpages;
			$this->subcategory_cnt = $num_subcats;
		}
		
		public function get_page_cnt()
		{
			return 1; //$this->subpage_cnt + 1;
		}
		
		public function get_category_cnt()
		{
			return 1; //$this->subcategory_cnt + 1;
		}
		
		public function to_html()
		{
			// calculate page information
			$cnt_subpages_direct = $this->subpage_cnt;
			$cnt_subcategories_direct = $this->subcategory_cnt;
			
			// add category page's html
			$indent = $this->page_depth*22;
			$category_html = <<<PAGE_HTML
<div class="result_div healthy page" style="margin-left:{$indent}px">
	<div class="result_icon">
		<img src="./img/icon_page.png" alt="healthy category"/>
	</div>
	<div class="result_body">
		<span class="result_query">$this->page_title</span>
		<span class="result_views">$this->page_views views</span>
		<br/>
		<div class="result_description">
			<span class="result_text_details">
				SubPages: $cnt_subpages_direct direct - SubCategories: $cnt_subcategories_direct direct
			</span>
		</div>
		<span class="result_url">
			<a href="$this->page_link" target="_blank">$this->page_url</a>
		</span>
	</div>
</div>
PAGE_HTML;
			
			return $category_html;
		}
	}
	
	
	
	/**
	 * Broken category pages are those with incorrect query
	 *     titles. These hold no view or url information and
	 *     do not contain a collection of subpages.
	 */
	class Broken_Category extends Broken_Page
	{
		public function to_html()
		{
			$indent = $this->page_depth*22;
			return <<<PAGE_HTML
<div class="result_div broken page" style="margin-left:{$indent}px">
	<div class="result_icon">
		<img src="./img/icon_broken.png" alt="broken category"/>
	</div>
	<div class="result_body">
		<span class="result_query">$this->page_title</span>
		<br/>
		<span class="result_url">
			Category Not Found
		</span>
	</div>
</div>
PAGE_HTML;
		}
	}
	
	
	
	/**
	 * Report is a collection of Pages.
	 */
	class Report
	{
		private $pages = array();
		private $search_depth = -1;
		
		public function __construct($depth)
		{
			$this->search_depth = $depth;
		}
		
		public function add_page($new_page)
		{
			$this->pages[] = $new_page;
		}
		
		public function to_html()
		{
			// calculate report data
			$total_views = 0;
			$total_pages = 0;
			foreach( $this->pages as $page )
			{
				$total_views += $page->get_views();
				$total_pages += $page->get_page_cnt();
			}
			
			// add header html
			$report_html = <<<PAGE_HTML
<div class="results_header">
	Reporting with a search depth of $this->search_depth on a total of <b>$total_pages pages</b> with a sum of <b>$total_views views</b>.
</div>
PAGE_HTML;
			
			// add pages' html
			foreach( $this->pages as $page )
				$report_html .= $page->to_html();
			
			return $report_html;
		}
	}
	
	
?>


