
<?php
	$xml_string = <<<XML
<table>
	<coolstuff> I'm cool </coolstuff>
	")slkjsdlkfjlskjdf"
	slfkjslkdjf
	<description> amazing </description>
	garbage here
	<level1>
		level 1 text
		<level2>
			level 2 text
		</level2>
		<level2>
			<level3>
				level 3 text
			</level3>
		</level2>
	</level1>
</table>
XML;
	
	$xml_obj = new SimpleXMLElement($xml_string);
	
	$result = $xml_obj->children();
	foreach( $result as $value )
		echo "Value = " . $value . "<br/>";
?>