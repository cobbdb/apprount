
<?php
	
	$html = <<<PAGE
<?xml version="1.1" encoding="utf-8" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head></head>
	<body>
		<div id="mw-pages">
			Fuck this
			<div id="second">
				Fuck all
			</div>
			Fuck it
		</div>
	</body>
</html>
PAGE;
	
	$doc = new DOMDocument();
	$doc->validateOnParse = true;
	$doc->loadHTML($html);
	
	$html_string = $doc->saveXML($doc->getElementById("mw-pages"));
	echo html_entity_decode($html_string);
?>


