
function nbr()
{
	var c,b,e,a;
	if(d.x.q.value==""||d.x.q.value=="put search terms here")
	{
		d.x.q.value="put search terms here";
		d.x.q.style.color="#AAAAAA";
		setTimeout("d.x.q.onclick();d.x.q.focus();",1000);
		return false
	}

	c=new RegExp(" \\!([^\\s]+)$");
	b=new RegExp("^\\!([^\\s]+) ");
	
	if(c.test(d.x.q.value)||b.test(d.x.q.value))
	{
		e=RegExp.$1||0;
		if(e&&grb.test(e))
		{
			a=YAHOO.util.Cookie.getSub("!",e)||0;
			a++;
			if(!kq||kq=="1")
			{
				YAHOO.util.Cookie.setSub("!",e,a,{expires:new Date("January 12, 2025")})
			}
		}
	}

	return true

}
