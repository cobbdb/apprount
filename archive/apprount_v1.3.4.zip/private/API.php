<?php

/**
 * Api.php
 * 
 * @author Dan Cobb
 * @since 1.3.4
 * @date October 5, 2012
 */

require_once "Page.php";
require_once "PageFactory.php";


/**
 * Convenience class for category information.
 */
class CategoryReport {
    private $pageTitles;
    private $categoryCount = 0;
    
    /**
     * @param {Array} titles Collection of page titles.
     */
    public function __construct($titles) {
        $this->pageTitles = $titles;
        foreach ($this->pageTitles as $title) {
            if (Page::isCategory($title)) {
                $this->categoryCount++;
            }
        }
    }
    
    public function getSubpageTitles() {
        return $this->pageTitles;
    }
    
    public function getSubpageCount() {
        return sizeof($this->pageTitles);
    }
    
    public function getSubcategoryCount() {
        return $this->categoryCount;
    }
}


/**
 * Collection of tools to handle Appropedia page operations.
 */
final class API {
    /**
     * Query MediaWiki API for information.
     * @param {String} req Query string.
     * @returns API response.
     */
    public static function query($req) {
        $url = "http://www.appropedia.org/api.php";
        return file_get_contents($url . $req);
    }
    
    /**
     * @param depth
     * @param titles
     * @returns {Report} Search report.
     */
    public static function newReport($depth, $searchString) {
        $titles = explode("|", $searchString);
        $info = self::getTitleInfo($titles);
        
        $report = new Report($depth);
        foreach ($info as $page) {
            $report->addPage(PageFactory::newPage($page, 0, $depth));
        }
        return $report;
    }
    
    /**
     * Factory for category report.
     * @param categoryTitle
     * @returns {CategoryReport}
     */
    public static function newCategoryReport($categoryTitle) {
        $titleList = self::getSubtitles($categoryTitle);
        return new CategoryReport($titleList);
    }
    
    /**
     * Query MediaWiki for page information on a set of page titles.
     * @param {Array} allTitles Collection of page titles.
     * @returns {Array} 
     */
    public static function getTitleInfo($allTitles) {
        $length = sizeof($allTitles);
        $results = Array();
        
        for ($i = 0; $i < $length; $i += $querySize) {
            // Only increments of 50.
            $querySize = min($length, 50);
            $titles = array_slice($allTitles, $i, $querySize);
            
            $results += self::queryTitleInfo($titles);
        }
        
        return $results;
    }
    
    /**
     * Build a list of page titles contained under a category.
     * @param {String} root Root page to search through.
     * @returns {Array} Page titles.
     */
    private static function getSubtitles($root) {
        $titles = Array();
        
        $root = rawurlencode($root);
        $query = "?format=php&action=query&redirects=true&list=categorymembers&cmprop=title&cmlimit=500&cmtitle=$root";
        $continueCode = "";
        
        do {
            $res = self::query($query . $continueCode);
            $data = unserialize($res);
            
            foreach ($data["query"]["categorymembers"] as $page) {
                $titles[] = $page["title"];
            }
            
            $continue = isset($data["query-continue"]);
            if ($continue) {
                $continueCode = "&cmcontinue=" . $data["query-continue"]["categorymembers"]["cmcontinue"];
            }
        } while ($continue);
        
        return $titles;
    }
    
    /**
     * Query for page info on a set of titles.
     * @param {Array} titles Collection of page titles.
     * @returns {Array} Page information.
     */
    private static function queryTitleInfo($titles) {
        $query = "?format=php&action=query&prop=info&redirects=true&titles=";
        
        $titles = implode("|", $titles);
        $titles = rawurlencode($titles);
        
        $res = self::query($query . $titles);
        $data = unserialize($res);
        return $data["query"]["pages"];
    }
}
