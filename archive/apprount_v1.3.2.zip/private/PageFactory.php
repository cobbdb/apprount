<?php

/**
 * PageFactory.php
 * 
 * @author Dan Cobb
 * @since 1.3.2
 * @date October 4, 2012
 */

require_once "Page.php";
require_once "API.php";


class PageFactory {
    private static $searchDepth = -1;
    
    /**
     * @param [searchDepth] Required on first call.
     * @returns Instance of an appropriate Page subclass.
     */
    public static function newPage($page, $pageDepth, $searchD = null) {
        // Set search depth on first call.
        if (isset($searchD)) {
            self::$searchDepth = $searchD;
        }
        
        if (Page::titleIsCategory($page["title"])) {
            return self::newCategory($page, $pageDepth);
        }
        return self::newLeaf($page, $pageDepth);
    }
    
    /**
     * @returns {Boolean} True if page is not broken.
     */
    private static function pageIsHealthy($page) {
        // healthy pages have a view counter key
        if (isset($page["counter"])) {
            return true;
        }
        return false;
    }
    
    
    
    /**
     * Creates one of: ContentPage, BrokenPage
     */
    private static function newLeaf($page, $pageDepth) {
        if (self::pageIsHealthy($page)) {
            return new ContentPage($page["title"], $page["counter"], $pageDepth);
        }
        return new BrokenPage($page["title"], $pageDepth);
    }
    
    
    
    /**
     * Creates one of: CategoryPage, LeafCategory, BrokenCategory
     */
    private static function newCategory($page, $pageDepth) {
        if (self::pageIsHealthy($page)) {
            // healthy categories have two types: node and leaf
            if ($pageDepth < self::$searchDepth) {
                return self::newCategoryPage($page["title"], $page["counter"], $pageDepth);
            }
            return self::newLeafCategory($page["title"], $page["counter"], $pageDepth);
        }
        return new BrokenCategory($page["title"], $pageDepth);
    }
    
    private static function newCategoryPage($title, $views, $pageDepth) {
        $categoryReport = API::newCategoryReport($title);
        
        $info = API::getTitleInfo($categoryReport->getSubpageTitles());
        
        $categoryPage = new CategoryPage($title, $views, $pageDepth);
        
        foreach ($info as $page) {
            // recurse to create the new page
            $newPage = self::newPage($page, $pageDepth + 1);
            $categoryPage->addPage($newPage);
        }
        
        return $categoryPage;
    }
    
    private static function newLeafCategory($title, $views, $depth) {
        // collect information on category
        $categoryReport = API::newCategoryReport($title);
        
        $subpageCount = $categoryReport->getSubpageCount();
        $subcategoryCount = $categoryReport->getSubcategoryCount();
        
        // create the empty category page
        return new LeafCategory($title, $views, $depth, $subpageCount, $subcategoryCount);
    }
}



