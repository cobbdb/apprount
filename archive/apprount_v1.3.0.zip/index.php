<?php

/**
 * index.php
 * Page routing for Apprount.
 * 
 * /?depth=<depth>&titles=<page title>[|<page title>]
 * 
 * @author Dan Cobb (cobbdb@gmail.com)
 * @version 1.3
 * @date September 22, 2012
 */

require_once "./private/ApprountApi.php";
require_once "../templates/Engine.php";

define("SECRET", "RobinHood123");

session_start();

$rTitles = @$_REQUEST["titles"];
$rDepth = @$_REQUEST["depth"];

// Ensure state.
if (isset($rTitles) and strlen($rTitles) > 0) {
    // Any request with a titles param -> search.
    $action = "search";
    $_SESSION["titles"] = $rTitles;
} elseif (isset($_SESSION["titles"]) and isset($_REQUEST["key"])) {
    // Verify search key.
    if ($_REQUEST["key"] == $_SESSION["key"]) {
        // No titles param and titles set in session -> report.
        $action = "report";
    } else {
        // Search key was invalid -> abort.
        exit;
    }
} else {
    // With no titles param and no titles in session -> index.
    $action = "index";
}


// Ensure depth parameter.
if ($action == "search") {
    if (isset($_REQUEST["depth"])) {
        // Correct for full search depth.
        if ($rDepth == "full") {
            $_SESSION["depth"] = 100;
        } else {
            // Search with a depth set -> use as requested.
            $_SESSION["depth"] = $rDepth;
        }
    } else {
        // Search with no depth set -> use default.
        $_SESSION["depth"] = 0;
    }
} elseif ($action == "report") {
    if (!isset($_SESSION["depth"])) {
        // Report with no depth set -> use default.
        $_SESSION["depth"] = 0;
    }
}


// Prepare header content.
$head = Template::render("./private/views/head.view");

switch ($action) {
    // Search-in-Progress page.
    case "search":
        // Salt the hash and store the key.
        $key = sha1(SECRET . rand());
        $_SESSION["key"] = $key;
        
        $body = Template::render("./private/views/search.view", Array(
            "key" => $key
        ));
        echo Template::render(null, Array(
            "head" => $head,
            "body" => $body
        ));
        break;
    
    
    // Conduct the actual search and respond.
    case "report":
        // Calculate page view information.
        $reportHTML = ApprountAPI::createReportHTML($_SESSION["depth"], $_SESSION["titles"]);
        session_destroy();
        
        // Render the report view.
        $res = Template::render("./private/views/report.view", Array(
            "results" => $reportHTML
        ));
        
        echo json_encode(Array(
            "report" => $res
        ));
        break;
    
    
    // Show index page.
    default:
        $body = Template::render("./private/views/index.view");
        echo Template::render(null, Array(
            "head" => $head,
            "body" => $body
        ));
        break;
}
