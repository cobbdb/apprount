$(function () {
    // Make ajax call to wait for results.
    $.ajax({
        url: "./",
        dataType: "json",
        type: "GET",
        data: {
            action: "report",
            key: $("#key").val()
        },
        cache: false,
        success: function (res) {
            $("#page").effect("slide", {
                mode: "hide"
            }, "slow", function () {
                $(this)
                    .html(res.report)
                    .effect("slide", {
                        direction: "right",
                        mode: "show"
                    }, "slow");
            });
        },
        error: function (xhr) {
            console.error(xhr.status + " : " + xhr.statusText);
        }
    });
});