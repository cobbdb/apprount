$(function () {
    // Toggle div on click.
    $(".category").toggle(
        function () {
            $(this).next().slideToggle();
            $(this).find("img").attr({
                src: "res/img/icon_minus.png"
            });
        },
        function () {
            $(this).next().slideToggle();
            $(this).find("img").attr({
                src: "res/img/icon_plus.png"
            });
        }
    );
    
    $(".result_url").click(function (e) {
        e.stopPropagation();
    });
});