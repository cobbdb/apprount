<?php
    
/**
 * Page.php
 * 
 * Abstract Page parents ContentPage and CategoryPage.
 * ContentPage is a leaf, while CategoryPage is a node
 *     that also has many properties of a leaf.
 * 
 * The HTML template is described in report_template.txt
 * 
 * @author Dan Cobb (cobbdb@gmail.com)
 * @version 1.3
 * @date September 16, 2012
 */


// Defines the contract of a Page
abstract class Page {
    protected $pageTitle = "UNREGISTERED_PAGE";
    protected $pageViews = -1;
    protected $pageUri = "UNREGISTERED_PAGE";
    protected $pageLink = "UNREGISTERED_PAGE";
    protected $pageDepth = -1;
    
    public abstract function toHTML();
    public abstract function getViews();
    public abstract function getWorth();
    public abstract function getPages();
    public abstract function getPageCnt();
    public abstract function getCategoryCnt();
    
    public function getTitle() {
        return $this->pageTitle;
    }
    
    // check if a title begins with Category:
    public static function titleIsCategory($title) {
        // i indicates case-insensitivity
        return (preg_match("/^(Category:)/i", $title) == 1);
    }
}


/**
 * ContentPage is a leaf of the report heirarchy containing
 *     pageview information, url, and toHTML/0
 */
class ContentPage extends Page {
    public function __construct($title, $views, $depth) {
        $this->pageTitle = $title;
        $this->pageViews = $views;
        $this->pageDepth = $depth;
        $this->pageUri = "appropedia.org/" . $title;
        
        // Some title contain slashes, so encode only each
        //   subpath of the title.
        $pathSections = explode("/", $title);
        $encodedSections = Array();
        foreach ($pathSections as $subpath) {
            $encodedSections[] = urlencode($subpath);
        }
        $this->pageLink = "http://www.appropedia.org/" . implode("/", $encodedSections);
    }
    
    // return total number of views on page
    public function getViews() {
        return $this->pageViews;
    }
    
    // return 1 if healthy page, 0 if broken page
    public function getWorth() {
        return 1;
    }
    
    // return map of title : views
    public function getPages() {
        return Array(
            $this->pageTitle => $this->pageViews
        );
    }
    
    // return 1 if healthy page, 0 if broken page
    public function getPageCnt() {
        return 1;
    }
    
    // return total number of categories in page
    public function getCategoryCnt() {
        return 0;
    }
    
    public function toHTML() {
        $indent = $this->pageDepth * 22;
        return <<<PAGE_HTML
<div class="result_div healthy page" style="margin-left:{$indent}px">
    <div class="result_icon">
        <img src="res/img/icon_page.png" alt="healthy page" />
    </div>
    <div class="result_body">
        <span class="result_query">{$this->pageTitle}</span>
        <span class="result_views">{$this->pageViews} views</span>
        <br />
        <span class="result_url">
            <a href="{$this->pageLink}" target="_blank">{$this->pageUri}</a>
        </span>
    </div>
</div>
PAGE_HTML;
    }
}



/**
 * Broken pages are those with incorrect query titles.
 *     These hold no view or url information.
 */
class BrokenPage extends ContentPage {
    public function __construct($title, $depth) {
        $this->pageTitle = $title;
        $this->pageDepth = $depth;
    }
    
    public function getViews() {
        return 0;
    }
    
    public function getWorth() {
        return 0;
    }
    
    public function getPages() {
        return Array();
    }
    
    public function getPageCnt() {
        return 0;
    }
    
    public function toHTML() {
        $indent = $this->pageDepth * 22;
        return <<<PAGE_HTML
<div class="result_div broken page" style="margin-left:{$indent}px">
    <div class="result_icon">
        <img src="res/img/icon_broken.png" alt="broken page" />
    </div>
    <div class="result_body">
        <span class="result_query">{$this->pageTitle}</span>
        <br />
        <span class="result_url">
            Page Not Found
        </span>
    </div>
</div>
PAGE_HTML;
    }
}



/**
 * CategoryPage is a child of Page that contains a
 *     collection of subpages.
 */
class CategoryPage extends ContentPage {
    // Next available category id
    private static $maxCatID = 0;
    // Each new category gets a unique page id
    private $catID;
    
    private $subpages = Array();
    
    private $subpageCnt = 0;
    private $subcategoryCnt = 0;
    
    public function __construct($title, $views, $depth) {
        parent::__construct($title, $views, $depth);
        $this->catID = self::$maxCatID;
        self::$maxCatID += 1;
    }
    
    public function addPage($newSubpage) {
        // check if page is a category
        if (parent::titleIsCategory($newSubpage->getTitle())) {
            $this->subcategoryCnt += $newSubpage->getWorth();
        }
        // add page to collection
        $this->subpages[] = $newSubpage;
        $this->subpageCnt += $newSubpage->getWorth();
    }
    
    // calculate total number of views for category and
    //     its subPAGES and all subpages for subcategories
    public function getViews() {
        $totalViews = $this->pageViews;
        foreach ($this->subpages as $page) {
            $totalViews += $page->getViews();
        }
        
        return $totalViews;
    }
    
    // calculate total number of subCATEGORIES for category
    public function getCategoryCnt() {
        $totalCategories = 1;
        foreach ($this->subpages as $page) {
            $totalCategories += $page->getCategoryCnt();
        }
        
        return $totalCategories;
    }
    
    // calculate total number of pages in category
    public function getPageCnt() {
        $totalPages = 1;
        foreach ($this->subpages as $page) {
            $totalPages += $page->getPageCnt();
        }
        
        return $totalPages;
    }
    
    public function getPages() {
        $myPages = parent::getPages();
        foreach ($this->subpages as $page) {
            $myPages += $page->getPages();
        }
        return $myPages;
    }
    
    public function toHTML() {
        // calculate page information
        $cntSubpagesDirect = $this->subpageCnt;
        $cntSubpagesTotal = $this->getPageCnt() - 1;
        $cntSubcategoriesDirect = $this->subcategoryCnt;
        $cntSubcategoriesTotal = $this->getCategoryCnt() - 1;
        $totalViews = $this->getViews();
        
        // add category page's html
        $indent = $this->pageDepth * 22;
        $categoryHTML = <<<PAGE_HTML
<div class="result_div healthy category" style="margin-left:{$indent}px">
    <div class="result_icon" id="icon_div_{$this->catID}">
        <img src="res/img/icon_plus.png" alt="healthy category" />
    </div>
    <div class="result_body">
        <span class="result_query">{$this->pageTitle}</span>
        <span class="result_views">{$this->pageViews} views</span>
        <br />
        <div class="result_description">
            <span class="result_text_total">$totalViews</span> total views of category page and contents.<br />
            <span class="result_text_details">
                SubPages: $cntSubpagesDirect direct / $cntSubpagesTotal total - SubCategories: $cntSubcategoriesDirect direct / $cntSubcategoriesTotal total
            </span>
        </div>
        <span class="result_url">
            <a href="{$this->pageLink}" target="_blank">{$this->pageUri}</a>
        </span>
    </div>
</div>
PAGE_HTML;
        
        // add category subpages' html
        $categoryHTML .= <<<PAGE_HTML
<div id="div_{$this->catID}" class="result_contents" style="display:none;">
PAGE_HTML;
        foreach ($this->subpages as $page) {
            $categoryHTML .= $page->toHTML();
        }
        
        $categoryHTML .= "</div>";
        
        return $categoryHTML;
    }
}



/**
 * Leaf category pages are those at the edge of the
 *     search depth and, therefore, have no subpages.
 */
class LeafCategory extends ContentPage {
    private $subpageCnt = 0;
    private $subcategoryCnt = 0;
    
    public function __construct($title, $views, $depth, $numSubpages, $numSubcats) {
        parent::__construct($title, $views, $depth);
        $this->subpageCnt = $numSubpages;
        $this->subcategoryCnt = $numSubcats;
    }
    
    public function getPageCnt() {
        return 1;
    }
    
    public function getCategoryCnt() {
        return 1;
    }
    
    public function toHTML() {
        // calculate page information
        $cntSubpagesDirect = $this->subpageCnt;
        $cntSubcategoriesDirect = $this->subcategoryCnt;
        
        // add category page's html
        $indent = $this->pageDepth * 22;
        $categoryHTML = <<<PAGE_HTML
<div class="result_div healthy page" style="margin-left:{$indent}px">
    <div class="result_icon">
        <img src="res/img/icon_page.png" alt="healthy category" />
    </div>
    <div class="result_body">
        <span class="result_query">{$this->pageTitle}</span>
        <span class="result_views">{$this->pageViews} views</span>
        <br />
        <div class="result_description">
            <span class="result_text_details">
                SubPages: $cntSubpagesDirect direct - SubCategories: $cntSubcategoriesDirect direct
            </span>
        </div>
        <span class="result_url">
            <a href="{$this->pageLink}" target="_blank">{$this->pageUri}</a>
        </span>
    </div>
</div>
PAGE_HTML;
        
        return $categoryHTML;
    }
}



/**
 * Broken category pages are those with incorrect query
 *   titles. These hold no view or url information and
 *   do not contain a collection of subpages.
 */
class BrokenCategory extends BrokenPage {
    public function toHTML() {
        $indent = $this->pageDepth * 22;
        return <<<PAGE_HTML
<div class="result_div broken page" style="margin-left:{$indent}px">
    <div class="result_icon">
        <img src="res/img/icon_broken.png" alt="broken category" />
    </div>
    <div class="result_body">
        <span class="result_query">{$this->pageTitle}</span>
        <br />
        <span class="result_url">
            Category Not Found
        </span>
    </div>
</div>
PAGE_HTML;
    }
}



/**
 * Report is a collection of Pages.
 */
class Report {
    private $pages = Array();
    private $searchDepth = -1;
    
    public function __construct($depth) {
        $this->searchDepth = $depth;
    }
    
    public function addPage($new_page) {
        $this->pages[] = $new_page;
    }
    
    public function toHTML() {
        // calculate report data
        $totalViews = 0;
        $totalPages = 0;
        foreach ($this->pages as $page) {
            $totalViews += $page->getViews();
            $totalPages += $page->getPageCnt();
        }
        
        // add header html
        $report_html = <<<PAGE_HTML
<div class="results_header">
    Reporting with a search depth of {$this->searchDepth} on a total of <b>$totalPages pages</b> with a sum of <b>$totalViews views</b>.
</div>
PAGE_HTML;
        
        // add pages' html
        foreach ($this->pages as $page) {
            $report_html .= $page->toHTML();
        }
        
        return $report_html;
    }
}
