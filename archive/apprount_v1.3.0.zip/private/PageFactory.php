<?php

/**
 * Page_Factory.php
 * 
 * Factory for all Pages. Single point of entry with
 *     internal branching.
 * 
 * @author Dan Cobb (cobbdb@gmail.com)
 * @version 1.3
 * @date September 16, 2012
 */

include_once("Page.php");

class PageFactory {
    // Seam for Page class
    // RETURNS: Instance of an appropriate Page child based on xml
    public static function newPage($pageXML, $pageDepth, $searchDepth) {
        // check for category
        if (Page::titleIsCategory($pageXML["title"])) {
            return PageFactory::newCategory($pageXML, $pageDepth, $searchDepth);
        }
        // otherwise, a leaf page
        return PageFactory::newLeaf($pageXML, $pageDepth);
    }
    
    // RETURNS: true if xml is of an actual page.
    private static function xmlIsHealthy($pageXML) {
        // healthy pages have a view counter key
        if (isset($pageXML["counter"])) {
            return true;
        }
        // .. broken pages do not
        return false;
    }
    
    
    
    // Creates either a ContentPage or a BrokenPage
    private static function newLeaf($pageXML, $pageDepth) {
        if (PageFactory::xmlIsHealthy($pageXML)) {
            return PageFactory::newContentPage($pageXML["title"], $pageXML["counter"], $pageDepth);
        }
        return PageFactory::newBrokenPage($pageXML["title"], $pageDepth);
    }
    
    private static function newContentPage($title, $views, $depth) {
        return new ContentPage($title, $views, $depth);
    }
    
    private static function newBrokenPage($title, $depth) {
        return new BrokenPage($title, $depth);
    }
    
    
    
    // Creates one of: categoryPage, LeafCategory, BrokenCategory
    private static function newCategory($pageXML, $pageDepth, $searchDepth) {
        if (PageFactory::xmlIsHealthy($pageXML)) {
            // healthy categories have two types: node and leaf
            if ($pageDepth < $searchDepth) {
                return PageFactory::newCategoryPage($pageXML["title"], $pageXML["counter"], $pageDepth, $searchDepth);
            }
            return PageFactory::newLeafCategory($pageXML["title"], $pageXML["counter"], $pageDepth);
        }
        return PageFactory::newBrokenCategory($pageXML["title"], $pageDepth);
    }
    
    private static function newCategoryPage($title, $views, $pageDepth, $searchDepth) {
        // collect information on category
        $categoryReport = ApprountAPI::newCategoryReport($title);
        
        // create empty category page
        $categoryPage = new CategoryPage($title, $views, $pageDepth);
        
        // query api
        $xmlObjAPIReports = ApprountAPI::query($categoryReport->getSubpageTitles());
        
        // add pages to category page
        foreach ($xmlObjAPIReports as $apiReport) {
            // for each page in each report
            foreach ($apiReport->query->pages->page as $xmlPageReport) {
                // recurse to create the new page
                $newPage = PageFactory::newPage($xmlPageReport, $pageDepth + 1, $searchDepth);
                
                // add new page to category
                $categoryPage->addPage($newPage);
            }
        }
        
        // return category page
        return $categoryPage;
    }
    
    private static function newLeafCategory($title, $views, $depth) {
        // collect information on category
        $categoryReport = ApprountAPI::newCategoryReport($title);
        
        $subpageCount = $categoryReport->getSubpageCount();
        $subcategoryCount = $categoryReport->getSubcategoryCount();
        
        // create the empty category page
        $categoryPage = new LeafCategory($title, $views, $depth, $subpageCount, $subcategoryCount);
        
        // return new page
        return $categoryPage;
    }
    
    private static function newBrokenCategory($title, $depth) {
        return new BrokenCategory($title, $depth);
    }
}



