<?php
    
/**
 * Page.php
 * 
 * @author Dan Cobb
 * @since 1.3.1
 * @date September 30, 2012
 */


require_once $_SERVER["DOCUMENT_ROOT"] . "/util/Engine.php";


// Defines the contract of a Page
abstract class Page {
    protected $pageTitle = "UNREGISTERED_PAGE";
    protected $pageViews = -1;
    protected $pageURI = "UNREGISTERED_PAGE";
    protected $pageLink = "UNREGISTERED_PAGE";
    protected $pageDepth = -1;
    
    public abstract function toHTML();
    public abstract function toWiki($searchDepth);
    public abstract function toCSV();
    
    public abstract function getViews();
    public abstract function getWorth();
    public abstract function getPages();
    public abstract function getPageCnt();
    public abstract function getCategoryCnt();
    
    public function getTitle() {
        return $this->pageTitle;
    }
    
    // check if a title begins with Category:
    public static function titleIsCategory($title) {
        // i indicates case-insensitivity
        return preg_match("/^(Category:)/i", $title);
    }
}



/**
 * ContentPage is a leaf of the report heirarchy containing
 *     pageview information, url, and toHTML/0
 */
class ContentPage extends Page {
    public function __construct($title, $views, $depth) {
        $this->pageTitle = $title;
        $this->pageViews = $views;
        $this->pageDepth = $depth;
        $this->pageURI = "appropedia.org/" . $title;
        
        // Some title contain slashes, so encode only each
        //   subpath of the title.
        $pathSections = explode("/", $title);
        $encodedSections = Array();
        foreach ($pathSections as $subpath) {
            $encodedSections[] = urlencode($subpath);
        }
        $this->pageLink = "http://www.appropedia.org/" . implode("/", $encodedSections);
    }
    
    // return total number of views on page
    public function getViews() {
        return $this->pageViews;
    }
    
    // return 1 if healthy page, 0 if broken page
    public function getWorth() {
        return 1;
    }
    
    // return map of title : views
    public function getPages() {
        return Array(
            $this->pageTitle => $this->pageViews
        );
    }
    
    // return 1 if healthy page, 0 if broken page
    public function getPageCnt() {
        return 1;
    }
    
    // return total number of categories in page
    public function getCategoryCnt() {
        return 0;
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/contentpage.html.view", Array(
            "indent" => $this->pageDepth * 22,
            "pageTitle" => $this->pageTitle,
            "pageViews" => $this->pageViews,
            "pageLink" => $this->pageLink,
            "pageURI" => $this->pageURI
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/contentpage.wiki.view", Array(
            "pageTitle" => $this->pageTitle,
            "pageViews" => $this->pageViews,
            "pageDepth" => $this->pageDepth,
            "searchDepth" => $searchDepth
        ));
    }
    
    public function toCSV() {
        return "CSV String";
    }
}



/**
 * Broken pages are those with incorrect query titles.
 *     These hold no view or url information.
 */
class BrokenPage extends ContentPage {
    public function __construct($title, $depth) {
        $this->pageTitle = $title;
        $this->pageDepth = $depth;
    }
    
    public function getViews() {
        return 0;
    }
    
    public function getWorth() {
        return 0;
    }
    
    public function getPages() {
        return Array();
    }
    
    public function getPageCnt() {
        return 0;
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/brokenpage.html.view", Array(
            "indent" => $this->pageDepth * 22,
            "alt" => "broken page",
            "pageTitle" => $this->pageTitle,
            "msg" => "Page Not Found"
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/brokenpage.wiki.view", Array(
            "pageDepth" => $this->pageDepth,
            "searchDepth" => $searchDepth,
            "msg" => "Page Not Found: " . $this->pageTitle
        ));
    }
}



/**
 * CategoryPage is a child of Page that contains a
 * collection of subpages.
 */
class CategoryPage extends ContentPage {
    // Next available category id
    private static $maxCatID = 0;
    // Each new category gets a unique page id
    private $catID;
    
    private $subpages = Array();
    
    private $subpageCnt = 0;
    private $subcategoryCnt = 0;
    
    public function __construct($title, $views, $depth) {
        parent::__construct($title, $views, $depth);
        $this->catID = self::$maxCatID;
        self::$maxCatID += 1;
    }
    
    public function addPage($newSubpage) {
        // check if page is a category
        if (parent::titleIsCategory($newSubpage->getTitle())) {
            $this->subcategoryCnt += $newSubpage->getWorth();
        }
        // add page to collection
        $this->subpages[] = $newSubpage;
        $this->subpageCnt += $newSubpage->getWorth();
    }
    
    // calculate total number of views for category and
    //     its subPAGES and all subpages for subcategories
    public function getViews() {
        $totalViews = $this->pageViews;
        foreach ($this->subpages as $page) {
            $totalViews += $page->getViews();
        }
        
        return $totalViews;
    }
    
    // calculate total number of subCATEGORIES for category
    public function getCategoryCnt() {
        $totalCategories = 1;
        foreach ($this->subpages as $page) {
            $totalCategories += $page->getCategoryCnt();
        }
        
        return $totalCategories;
    }
    
    // calculate total number of pages in category
    public function getPageCnt() {
        $totalPages = 1;
        foreach ($this->subpages as $page) {
            $totalPages += $page->getPageCnt();
        }
        
        return $totalPages;
    }
    
    public function getPages() {
        $myPages = parent::getPages();
        foreach ($this->subpages as $page) {
            $myPages += $page->getPages();
        }
        return $myPages;
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/categorypage.html.view", Array(
            "indent" => $this->pageDepth * 22,
            "catID" => $this->catID,
            "pageTitle" => $this->pageTitle,
            "pageLink" => $this->pageLink,
            "pageURI" => $this->pageURI,
            "pageViews" => $this->pageViews,
            "totalViews" => $this->getViews(),
            "cntSubpagesDirect" => $this->subpageCnt,
            "cntSubpagesTotal" => $this->getPageCnt() - 1,
            "cntSubcategoriesDirect" => $this->subcategoryCnt,
            "cntSubcategoriesTotal" => $this->getCategoryCnt() - 1,
            "subpages" => $this->subpages
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/categorypage.wiki.view", Array(
            "pageTitle" => $this->pageTitle,
            "pageViews" => $this->pageViews,
            "pageDepth" => $this->pageDepth,
            "searchDepth" => $searchDepth,
            "totalViews" => $this->getViews(),
            "subpages" => $this->subpages
        ));
    }
}



/**
 * Leaf category pages are those at the edge of the
 *     search depth and, therefore, have no subpages.
 */
class LeafCategory extends ContentPage {
    private $subpageCnt = 0;
    private $subcategoryCnt = 0;
    
    public function __construct($title, $views, $depth, $numSubpages, $numSubcats) {
        parent::__construct($title, $views, $depth);
        $this->subpageCnt = $numSubpages;
        $this->subcategoryCnt = $numSubcats;
    }
    
    public function getPageCnt() {
        return 1;
    }
    
    public function getCategoryCnt() {
        return 1;
    }
    
    public function toHTML() {
        return Template::render("./private/views/pages/leafcategory.html.view", Array(
            "indent" => $this->pageDepth * 22,
            "pageTitle" => $this->pageTitle,
            "pageViews" => $this->pageViews,
            "cntSubpagesDirect" => $this->subpageCnt,
            "cntSubcategoriesDirect" => $this->subcategoryCnt,
            "pageLink" => $this->pageLink,
            "pageURI" => $this->pageURI
        ));
    }
}



/**
 * Broken category pages are those with incorrect query
 *   titles. These hold no view or url information and
 *   do not contain a collection of subpages.
 */
class BrokenCategory extends BrokenPage {
    public function toHTML() {
        return Template::render("./private/views/pages/brokenpage.html.view", Array(
            "indent" => $this->pageDepth * 22,
            "alt" => "broken category",
            "pageTitle" => $this->pageTitle,
            "msg" => "Category Not Found"
        ));
    }
    
    public function toWiki($searchDepth) {
        return Template::render("./private/views/pages/brokenpage.wiki.view", Array(
            "pageDepth" => $this->pageDepth,
            "searchDepth" => $searchDepth,
            "msg" => "Category Not Found: " . $this->pageTitle
        ));
    }
}
