
<?php
	
	/**
	 * Create a test page heirarchy and display it.
	 */
	
	include_once("./private/Page.php");
	include_once("./private/Page_Factory.php");
	
	//$report_html = build_report1();
	$report_html = build_report2();
	
	sleep( 3 ); // pretend to take time
	
	// grab page template
	$page_html = file_get_contents("./private/results.html");
	
	// place report in template and output
	echo preg_replace("%!contents!%", $report_html, $page_html);
	
	
	
	function build_report1()
	{
		$report = new Report(1);
		
		$report->add_page( new Content_Page("Tire shingles", 2, 0) );
		
		$cat_page = new Category_Page("Category:Waterpod", 5, 0);
			$cat_page->add_page( new Content_Page("Waterpod Energy System", 3, 1) );
		$report->add_page( $cat_page );
		
		$report->add_page( new Content_Page("Solar Hot Air Popcorn Maker", 5, 0) );
		
		return $report->to_html();
	}
	
	function build_report2()
	{
		$report = new Report(2);
		
		$report->add_page( new Content_Page("Healthy Page name", 2, 0) );
		
		$report->add_page( new Broken_Page("broken Page name", 0) );
		
		$cat_page1 = new Category_Page("Category:Healthy category name", 5, 0);
			$cat_page1->add_page( new Content_Page("Healthy Page", 2, 1) );
			$cat_page2 = new Category_Page("Category:Short Healthy category name", 5, 1);
				$cat_page2->add_page( new Content_Page("Content Page", 2, 2) );
				//$cat_page2->add_page( new Content_Page("Category: Short deep", 5, 2) );
				$cat_page3 = new Leaf_Category("Category: Short deep", 5, 2, 3, 2);
				$cat_page2->add_category( $cat_page3 );
			$cat_page1->add_category( $cat_page2 );
			$cat_page1->add_page( new Broken_Page("Broken Page", 1) );
		$report->add_page( $cat_page1 );
		
		$report->add_page( new Broken_Category("category:broken category name", 0) );
		
		return $report->to_html();
	}
?>










