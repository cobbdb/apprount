
<?php
	
	/**
	 * Page_Factory.php
	 * 
	 * Factory for all Pages. Single point of entry with
	 *     internal branching.
	 * 
	 * By: Dan Cobb
	 * Last Modified: 3/25/12
	 */
	
	include_once("Page.php");
	
	class Page_Factory
	{
		// Seam for Page class
		// RETURNS: Instance of an appropriate Page child based on xml
		public static function new_page( $page_xml_obj, $page_depth, $search_depth )
		{
			// check for category
			if( Page::title_is_category($page_xml_obj["title"]) )
				return self::get_new_category( $page_xml_obj, $page_depth, $search_depth );
			// otherwise, page
			return self::get_new_page( $page_xml_obj, $page_depth );
		}
		
		// RETURNS: true if xml is of an actual page.
		private static function xml_is_healthy( $page_xml_obj )
		{
			// healthy pages have a view counter key
			if( isset($page_xml_obj["counter"]) )
				return true;
			// .. broken pages do not
			return false;
		}
		
		
		
		// Creates either a Content_Page or a Broken_Page
		private static function get_new_page( $page_xml_obj, $page_depth )
		{
			if( Page_Factory::xml_is_healthy($page_xml_obj) )
				return self::new_content_page( $page_xml_obj["title"], $page_xml_obj["counter"], $page_depth );
			return self::new_broken_page( $page_xml_obj["title"], $page_depth );
		}
		
		private static function new_content_page( $title, $views, $depth )
		{
			return new Content_Page( $title, $views, $depth );
		}
		
		private static function new_broken_page( $title, $depth )
		{
			return new Broken_Page( $title, $depth );
		}
		
		
		
		// Creates one of: Category_Page, Leaf_Category, Broken_Category
		private static function get_new_category( $page_xml_obj, $page_depth, $search_depth )
		{
			if( Page_Factory::xml_is_healthy($page_xml_obj) )
			{
				// healthy categories have two types: node and leaf
				if( $page_depth < $search_depth )
					return self::new_category_page( $page_xml_obj["title"], $page_xml_obj["counter"], $page_depth, $search_depth );
				return self::new_leaf_category( $page_xml_obj["title"], $page_xml_obj["counter"], $page_depth );
			}
			return self::new_broken_category( $page_xml_obj["title"], $page_depth );
		}
		
		private static function new_category_page( $title, $views, $page_depth, $search_depth )
		{
			// collect information on category
			$category_report = Apprount_API::new_category_report($title);
			
			// create empty category page
			$category_page = new Category_Page( $title, $views, $page_depth );
			
			// query api
			$xml_obj_api_reports = Apprount_API::query_appropedia($category_report->get_subpage_titles());
			
			// add pages to category page
			foreach( $xml_obj_api_reports as $api_report )
			{
				// for each page in each report
				foreach( $api_report->query->pages->page as $xml_page_report )
				{
					// recurse to create the new page
					$new_page = Page_Factory::new_page($xml_page_report, $page_depth+1, $search_depth);
					
					// add new page to category
					$category_page->add_page( $new_page );
				}
			}
			
			// return category page
			return $category_page;
		}
		
		private static function new_leaf_category( $title, $views, $depth )
		{
			// collect information on category
			$category_report = Apprount_API::new_category_report($title);
			
			$subpage_cnt = $category_report->get_subpage_cnt();
			$subcategory_cnt = $category_report->get_subcategory_cnt();
			
			// create the empty category page
			$category_page = new Leaf_Category( $title, $views, $depth, $subpage_cnt, $subcategory_cnt );
			
			// return new page
			return $category_page;
		}
		
		private static function new_broken_category( $title, $depth )
		{
			return new Broken_Category( $title, $depth );
		}
	}

?>

