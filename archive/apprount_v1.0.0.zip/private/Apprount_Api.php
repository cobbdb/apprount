<?php
	
	/**
	 * Apprount_Api.php
	 * API for Apprount
	 * 
	 * Counts pageviews for pages linked under any
	 * appropedia category page.
	 * Echos back results page filled with page view reports.
	 *
	 * <fname>.php?depth=<search depth>&titles=<page title>
	 * 
	 * By: Dan Cobb (cobbdb@gmail.com)
	 * Last Modified: March 25, 2012
	 */
	
	include_once("Page.php");
	include_once("Page_Factory.php");
	
	
	/////////////////////////////////////////
	// Apprount API Definition
	
	
	// Contains information on a category
	class Category_Report
	{
		private $page_titles;
		private $category_cnt = 0;
		
		// PARAM: titles is an array of page titles
		public function __construct($titles)
		{
			$this->page_titles = $titles;
			foreach( $this->page_titles as $title )
				if( Page::title_is_category($title) )
					$this->category_cnt++;
		}
		
		public function get_subpage_titles()
		{
			return $this->page_titles;
		}
		
		public function get_subpage_cnt()
		{
			return sizeof($this->page_titles);
		}
		
		public function get_subcategory_cnt()
		{
			return $this->category_cnt;
		}
	}
	
	
	// Collection of tools to handle Appropedia page operations
	final class Apprount_API
	{
		
		// Create html for an Apprount search query
		public static function create_report_html($search_depth, $titles_string)
		{
			// parse string of titles
			$appro_titles = explode("|", $titles_string);
			
			// query appropedia api for page information
			$xml_obj_api_reports = Apprount_API::query_appropedia( $appro_titles );
			
			// create a new report
			$report = new Report( $search_depth );
			
			// add pages to report
			foreach( $xml_obj_api_reports as $api_report )
			{
				// for each page in each report
				foreach( $api_report->query->pages->page as $xml_page_report )
				{
					//$xml_string = preg_replace("%<%", "!", $xml_page_report->asXML());
					//echo "XML>" . $xml_string . "<";
					
					// create the new page
					$new_page = Page_Factory::new_page($xml_page_report, 0, $search_depth);
					
					// add new page to category
					$report->add_page( $new_page );
				}
			}
			
			/*
			// collect entire list of subpage titles from page
			try
			{
				$titles = get_all_titles($appro_host, $root_page);
			} catch( Exception $ex )
			{
				echo "<a href=" . $_SERVER['PHP_SELF'] . "><- back</a>";
				echo "<br/><br/><u><b>An Error Occurred:</b></u><br/>";
				echo $ex->getMessage();
				return;
			}*/
			
			// conver the report to html
			return $report->to_html();
		}
		
		
		// Factory for category report
		public static function new_category_report($category_title)
		{
			$appro_host = "http://www.appropedia.org";
			$root_page = "/" . rawurlencode($category_title);
			
			// create list of titles
			$title_list = self::get_all_titles($appro_host, $root_page);
			// create a new category report
			return new Category_Report( $title_list );
		}
		
		
		// Create an array of xml reports from Appropedia API
		public static function query_appropedia( $page_titles )
		{
			// create the collection of reports
			return self::get_subpage_info( $page_titles );
		}
		
		
		
		
		/////////////////////////////////////////
		// Private Methods
		
		
		// Collect entire list of subpage titles from starting page.
		// PARAMS: appro_host appropedia domain url
		//         next_page root page to search through
		// RETURNS: comprehensive array of page titles
		private static function get_all_titles($appro_host, $next_page)
		{
			// collection of subpage titles
			$titles = array();
			
			// links are in groups of 200 across several pages, so
			//     loop through them all collecting title names
			do
			{
				// next url
				$appro_url = $appro_host . $next_page;
				
				// get the html of the div containing links
				$links_html = self::get_pages_links_div($appro_url);
				
				// turn html into array of titles and add to existing collection
				$titles = array_merge($titles, self::get_titles($links_html));
				
				// get url of next page of links
				$next_page = self::get_next_link($links_html);
			} while( $next_page );
			
			return $titles;
		}
		
		
		// Fetch link to continuing category page (next 200).
		// PARAMS: links_html mw-pages div
		// RETURNS: url of next category page
		//          false if no link was found
		private static function get_next_link($links_html)
		{
			// locate the start of the 'next 200' anchor
			if( preg_match("%\(<a.+?next 200</a>%", $links_html, $matches) )
			{
				// return only the link url
				$link_start = stripos($matches[0], "\"") + 1; // just after first double-quote
				$link_end = stripos($matches[0], "\"", $link_start); // second double-quote
				$link_width = $link_end - $link_start;
				$url = substr($matches[0], $link_start, $link_width);
				// convert chars like &amp; back into &
				return htmlspecialchars_decode($url);
			}
			
			// no 'next' link was found
			return false;
		}
		
		/*
		// Construct a report and sum total pageviews for subpages.
		// PARAMS: subpage_info (title, count) pairs per subpage
		//         filter_users true if user pages should not be included in report
		// RETURNS: Report instance loaded with page data
		private static function build_report( $subpage_info, $filter_users )
		{
			$total_views = 0;
			$page_count = 0;
			
			// create a report and calculate page stats
			$report_html = '<table>';
			reset($subpage_info);
			while( list($page_title, $count) = each($subpage_info) )
			{
				// create row
				$row_html = '<tr>';
				$row_html .= "<td style='border-bottom:solid thin'>" . $page_title . "</td>";
				$row_html .= '<td>' . $count . "</td>";
				$row_html .= "</tr>";
				
				// record page information if not a user page
				if( !preg_match("%^User( talk)?:.+%", $page_title) or !$filter_users )
				{
					// add row to table
					$report_html .= $row_html;
					// record page inclusion
					$page_count++;
					// add to total count
					$total_views += $count;
				}
			}
			$report_html .= "</table>";
			
			// create report
			//return new Report($report_html, $total_views, $page_count);
		}*/
		
		
		// Queries the framework for all titles
		// PARAMS: titles of all subpages.
		// RETURNS: array of subpages' info as (title, count)
		private static function get_subpage_info($titles)
		{
			// map of (title, count) for subpages
			$xml_reports = array();
			
			// number of pages LEFT to get info on
			$total_size = sizeof($titles);
			
			// api will only report back 50 pages at a time, so
			//    iterate through titles 50 at a time
			$num_iterations = ceil($total_size/50);
			
			// build the query
			for( $i=0; $i<$num_iterations; $i++ )
			{
				// reset query
				$query = "";
				
				// calculate how many titles to add
				$query_size = min( $total_size, 50 );
				
				// add to the query
				for( $j=0; $j<$query_size; $j++ )
				{
					$title_index = $j + $i*50;
					$query .= $titles[$title_index] . "|";
				}
				$query = substr( $query, 0, -1 ); // drop last pipe
				
				// mark that a batch of titles have been added
				$total_size -= $query_size;
				
				// create the url
				$query_url = "http://www.appropedia.org/api.php?format=xml&action=query&prop=info&titles=";
				$query_url .= rawurlencode($query); // encode the query
				
				// query the api
				$xml_string = file_get_contents($query_url);
				// create the XML object
				$xml_reports[] = new SimpleXMLElement($xml_string);
			}
			
			return $xml_reports;
		}
		
		
		// Constructs an array full of page titles.
		// PARAMS: links div containing links to pages of interest.
		// RETURNS: array full of page titles.
		private static function get_titles($links_html)
		{
			// cut out any inner-span tags
			$links_html = preg_replace("%</?span.*?>%", "", $links_html);
			
			// parse html as an xml object
			$page_xml = new SimpleXMLElement($links_html);
			
			// make a list to place titles in
			$titles = array();
			
			// get path to page links
			$result = $page_xml->xpath("//li/a"); // links not inside table
			if( !$result )
				$result = $page_xml->xpath("//////li/a"); // links inside table
			
			// grab titles from anchor tags
			foreach( $result as $anchor )
				$titles[] = $anchor["title"];
			
			// return list of titles
			return $titles;
		}
		
		
		// Substring the div containing links to pages of interest.
		// PARAMS: page url to pull html from.
		// RETURNS: string containing html of links div.
		private static function get_pages_links_div($page_url)
		{
			// get the page's html
			if( !$page_html = @file_get_contents($page_url) )
				throw new Exception("Failed to contact Appropedia at: " . rawurldecode($page_url));
			
			// find the starting index of the chunk of links we're after
			$index_start = stripos( $page_html, '<div id="mw-pages">' );
			
			// throw exception if div was not found
			if( !$index_start )
				throw new Exception("Page does not contain subpages.");
			
			// find the ending index of the chunk of links we're after
			$index_end   = stripos( $page_html, '</div>', $index_start );
			$index_end += 6; // offset to end of div tag
			
			// get length of links div
			$chunk_length = $index_end - $index_start;
			
			// substring the links div
			$links_html = substr( $page_html, $index_start, $chunk_length );
			
			return $links_html;
		}
		
		
		// Substring the div containing links to subcategories.
		// RETURNS: string containing html of links div.
		/*private static function get_categories_links_div($page_url)
		{
			// get the page's html
			if( !$page_html = @file_get_contents($page_url) )
				throw new Exception("Failed to contact Appropedia at: " . rawurldecode($page_url));
			
			// find the starting index of the chunk of links we're after
			$index_start = stripos( $page_html, '<div id="mw-pages">' );
			
			// throw exception if div was not found
			if( !$index_start )
				throw new Exception("Page does not contain subpages.");
			
			// find the ending index of the chunk of links we're after
			$index_end   = stripos( $page_html, '</div>', $index_start );
			$index_end += 6; // offset to end of div tag
			
			// get length of links div
			$chunk_length = $index_end - $index_start;
			
			// substring the links div
			$links_html = substr( $page_html, $index_start, $chunk_length );
			
			return $links_html;
		}*/
		
	}
	
?>










